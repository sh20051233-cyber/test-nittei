-- Supabase SQL Editor: run entire script once.
create extension if not exists pgcrypto with schema extensions;
create table if not exists public.nittei_events (
 id uuid primary key default gen_random_uuid(), title text not null check(length(title) between 1 and 120),
 days jsonb not null, start_time time not null, end_time time not null,
 interval_minutes int not null default 30 check(interval_minutes in (15,30,60)),
 admin_hash text not null, created_at timestamptz not null default now()
);
create table if not exists public.nittei_responses (
 event_id uuid not null references public.nittei_events(id) on delete cascade,
 name text not null check(length(name) between 1 and 60),
 password_hash text not null, answers jsonb not null default '{}'::jsonb,
 updated_at timestamptz not null default now(), primary key(event_id,name)
);
alter table public.nittei_events enable row level security;
alter table public.nittei_responses enable row level security;
revoke all on public.nittei_events,public.nittei_responses from anon,authenticated;
-- No table policies: all access through controlled RPCs.
create or replace function public.nittei_create(t text, d jsonb, st text, en text, step int, admin_password text)
returns uuid language plpgsql security definer set search_path = '' as $$
declare result uuid;
begin
 if length(trim(coalesce(t,''))) not between 1 and 120 or jsonb_typeof(d) is distinct from 'array' or jsonb_array_length(d) not between 1 and 31 or step not in (15,30,60) or st !~ '^([01][0-9]|2[0-3]):[0-5][0-9]$' or en !~ '^([01][0-9]|2[0-3]):[0-5][0-9]$' or st::time >= en::time or length(coalesce(admin_password,'')) < 6 then raise exception 'Invalid event settings'; end if;
 if exists(select 1 from jsonb_array_elements_text(d) x where x !~ '^\d{4}-\d{2}-\d{2}$') then raise exception 'Invalid date'; end if;
 if extract(epoch from (en::time-st::time))/60 > 1440 or mod(extract(epoch from (en::time-st::time))::int/60,step) <> 0 then raise exception 'Invalid time range'; end if;
 insert into public.nittei_events(title,days,start_time,end_time,interval_minutes,admin_hash)
 values(trim(t),d,st::time,en::time,step,extensions.crypt(admin_password,extensions.gen_salt('bf'))) returning id into result;
 return result;
end $$;
create or replace function public.nittei_view(eid uuid)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare e record; r jsonb;
begin
 select id,title,days,to_char(start_time,'HH24:MI') st,to_char(end_time,'HH24:MI') en,interval_minutes into e from public.nittei_events where id=eid;
 if not found then raise exception 'Event not found'; end if;
 select coalesce(jsonb_agg(jsonb_build_object('name',name,'answers',answers) order by name),'[]'::jsonb) into r from public.nittei_responses where event_id=eid;
 return jsonb_build_object('id',e.id,'title',e.title,'days',e.days,'start',e.st,'end',e.en,'step',e.interval_minutes,'responses',r);
end $$;
create or replace function public.nittei_save(eid uuid, person text, pass text, marks jsonb)
returns boolean language plpgsql security definer set search_path = '' as $$
declare stored text;
begin
 if not exists(select 1 from public.nittei_events where id=eid) then raise exception 'Event not found'; end if;
 if length(trim(coalesce(person,''))) not between 1 and 60 or length(coalesce(pass,'')) < 4 or length(pass)>100 or jsonb_typeof(marks) is distinct from 'object' or pg_column_size(marks)>50000 then raise exception 'Invalid response'; end if;
 if exists(select 1 from jsonb_each_text(marks) kv where kv.value not in ('o','t','x')) then raise exception 'Invalid mark'; end if;
 select password_hash into stored from public.nittei_responses where event_id=eid and name=trim(person) for update;
 if found then
  if stored <> extensions.crypt(pass,stored) then raise exception 'Wrong password for this name'; end if;
  update public.nittei_responses set answers=marks,updated_at=now() where event_id=eid and name=trim(person);
 else
  insert into public.nittei_responses(event_id,name,password_hash,answers) values(eid,trim(person),extensions.crypt(pass,extensions.gen_salt('bf')),marks);
 end if;
 return true;
end $$;
create or replace function public.nittei_delete(eid uuid, admin_password text)
returns boolean language plpgsql security definer set search_path = '' as $$
declare stored text;
begin
 select admin_hash into stored from public.nittei_events where id=eid;
 if stored is null or stored <> extensions.crypt(admin_password,stored) then raise exception 'Wrong admin password'; end if;
 delete from public.nittei_events where id=eid;
 return true;
end $$;
revoke all on function public.nittei_create(text,jsonb,text,text,int,text) from public;
revoke all on function public.nittei_view(uuid) from public;
revoke all on function public.nittei_save(uuid,text,text,jsonb) from public;
revoke all on function public.nittei_delete(uuid,text) from public;
grant execute on function public.nittei_create(text,jsonb,text,text,int,text),public.nittei_view(uuid),public.nittei_save(uuid,text,text,jsonb),public.nittei_delete(uuid,text) to anon,authenticated;
